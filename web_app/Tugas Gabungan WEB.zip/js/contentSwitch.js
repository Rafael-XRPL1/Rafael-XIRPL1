function loadContent(page) {
    const iframe = document.getElementById('contentFrame');
    iframe.src = page;
}
